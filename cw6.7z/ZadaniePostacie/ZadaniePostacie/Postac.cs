﻿using System;
using System.Collections.Generic;
using System.Text;



namespace ZadaniePostacie
{
    abstract class Postac
    {
        public int Hp { get; set; }
        public int Atak { get; set; }
        public int Obrona { get; set; }

        public override string ToString()
        {
            return $"HP: {Hp}, ATAK: {Atak}, OBRONA: {Obrona}";
        }

        public Postac(int hp, int atak, int obrona)
        {
            Hp = hp;
            Atak = atak;
            Obrona = obrona;
        }

        public void Ulepsz()
        {
            Random r = new Random();
            this.Hp += r.Next(1, 10);
            this.Atak += r.Next(1, 10);
            this.Obrona += r.Next(1, 10);
        }

        public void Lecz()
        {
            Random r = new Random();
            this.Hp += r.Next(5, 20);
        }

        public void Atakuj(Postac p)
        {
            p.Hp = p.Hp < this.Atak ? 0 : p.Hp - this.Atak;
            this.Hp = this.Hp < p.Obrona ? 0 : this.Hp - p.Obrona;
        }
    }
}
