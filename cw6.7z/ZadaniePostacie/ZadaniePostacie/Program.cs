﻿using System;

namespace ZadaniePostacie
{
    class Program
    {
        static void Main(string[] args)
        {
            Palkarz p1 = new Palkarz(100, 20, 15);
            Palkarz p2 = new Palkarz(100, 34, 21);

            Wlocznik w1 = new Wlocznik(80, 40, 10);

            Console.WriteLine(p1);
            Console.WriteLine(p2);
            Console.WriteLine(w1);

            Console.WriteLine("Ulepszenie ----------");
            p1.Ulepsz();

            Console.WriteLine("Ataki ----------");
            p1.Atakuj(w1);
            w1.Atakuj(p1);
            w1.Atakuj(p2);
            p2.Atakuj(p2);

            Console.WriteLine("Po walce ----------");
            Console.WriteLine(p1);
            Console.WriteLine(p2);
            Console.WriteLine(w1);

            Console.WriteLine("Leczenie ----------");
            p1.Lecz();
            p2.Lecz();
            w1.Lecz();
            Console.WriteLine(p1);
            Console.WriteLine(p2);
            Console.WriteLine(w1);


        }
    }
}
