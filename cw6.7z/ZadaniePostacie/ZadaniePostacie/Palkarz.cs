﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZadaniePostacie
{
    class Palkarz : Postac
    {
        public Palkarz(int hp, int atak, int obrona) : base(hp, atak, obrona)
        {

        }

        public override string ToString()
        {
            return "Pałkarz - " + base.ToString();
        }
    }
}
