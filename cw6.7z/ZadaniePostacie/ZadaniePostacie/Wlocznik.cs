﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZadaniePostacie
{
    class Wlocznik : Postac
    {
        public Wlocznik(int hp, int atak, int obrona) : base(hp, atak, obrona)
        {

        }

        public override string ToString()
        {
            return "Włócznik - " + base.ToString();
        }
    }
}
